# flake8: noqa: F401
from freqtrade.leverage.interest import interest
