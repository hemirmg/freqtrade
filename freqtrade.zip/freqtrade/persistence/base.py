
from typing import Any

from sqlalchemy.orm import declarative_base


_DECL_BASE: Any = declarative_base()
